const app = document.querySelector('#app');
let view = 'landing';
let selectedRole = 'ship';
let onlinePosts = [];
let receivedReplies = [];
let chatRoom = '';
let selected = null;
let chatPoll = null;

const nativeFetch = window.fetch.bind(window);
window.fetch = (input, init = {}) => {
  if (typeof input === 'string' && input.startsWith('/api/')) {
    const session = sessionStorage.getItem('sealinkSession');
    if (session) init.headers = { ...(init.headers || {}), authorization: `Bearer ${session}` };
  }
  return nativeFetch(input, init);
};

function esc(value = '') { return String(value).replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' })[c]); }
function isLoggedIn() { return Boolean(sessionStorage.getItem('sealinkUserId')); }
function roleName(role) { return role === 'ship' ? '선박 회원' : '업체 회원'; }

function render() {
  clearInterval(chatPoll);
  if (view === 'landing') return landing();
  if (view === 'githublogin') return githubLogin();
  if (view === 'home') return home();
  if (view === 'compose') return compose();
  if (view === 'reply') return reply();
  if (view === 'chat') return chat();
}

function landing() {
  app.innerHTML = `<section class="role-landing">
    <button class="role-panel ship-panel" onclick="openLogin('ship')"><span class="role-icon">⚓</span><span class="role-kicker">VESSEL MEMBER</span><strong>선박 페이지</strong><em>선박 등록 · 폐선 상담 · 업체 연결</em><i>선박으로 로그인 →</i></button>
    <button class="role-panel business-panel" onclick="openLogin('company')"><span class="role-icon">♻</span><span class="role-kicker">BUSINESS MEMBER</span><strong>업체 페이지</strong><em>업체 등록 · 연결글 답변 · 고객 연결</em><i>업체로 로그인 →</i></button>
    <div class="role-intro"><img class="sundi-mascot" src="/assets/sundi.png" alt="선디 마스코트"><div class="eyebrow">BUSAN SMART VESSEL NETWORK</div><h1>SEA:<b>LINK</b></h1><p>선디와 함께 선박의 마지막 항해를<br>안전한 연결로 이어갑니다.</p><small>회원 유형을 선택해 GitHub로 로그인하세요.</small></div>
  </section>`;
}

function openLogin(role) { selectedRole = role; sessionStorage.setItem('pendingRole', role); view = 'githublogin'; render(); setTimeout(beginGithubLogin, 0); }

async function githubLogin() {
  app.innerHTML = `<div class="content login-page"><div class="screen-head"><button class="back" onclick="view='landing';render()">‹</button><div><h2>${roleName(selectedRole)} 로그인</h2><small>GitHub 계정으로 안전하게 로그인합니다.</small></div></div><div class="login-form github-login-card"><div class="role-pill">${selectedRole === 'ship' ? '⚓ 선박 페이지' : '♻ 업체 페이지'}</div><h3>GitHub로 계속하기</h3><p>아래 버튼을 누르면 GitHub 인증 페이지가 열립니다.</p><button class="btn btn-primary" onclick="beginGithubLogin()">GitHub 로그인 시작 →</button></div></div>`;
}

async function beginGithubLogin() {
  const box = document.querySelector('.github-login-card');
  try {
    const response = await fetch('/api/auth/github/device', { method: 'POST' });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'GitHub 인증을 시작하지 못했습니다.');
    box.innerHTML = `<div class="role-pill">GitHub 인증 진행 중</div><h3>아래 코드를 GitHub에 입력하세요</h3><div class="github-code">${esc(data.user_code)}</div><p><b>1.</b> 열린 GitHub 페이지에서 로그인합니다.<br><b>2.</b> 위 코드를 입력하고 접근을 승인합니다.</p><a class="github-open" href="${esc(data.verification_uri)}" target="_blank" rel="noopener">GitHub 인증 페이지 열기</a><p class="login-hint">인증 완료를 기다리는 중입니다. 이 화면은 자동으로 전환됩니다.</p>`;
    window.open(data.verification_uri, '_blank', 'noopener');
    const delay = Math.max(Number(data.interval || 5), 5) * 1000;
    const poll = async () => {
      const result = await fetch('/api/auth/github/poll', { method: 'POST', headers: { 'content-type':'application/json' }, body: JSON.stringify({ device_code: data.device_code }) });
      const body = await result.json();
      if (result.ok && body.authenticated) return finishLogin(body);
      if (body.error === 'authorization_pending' || body.error === 'slow_down') return setTimeout(poll, delay);
      throw new Error(body.error_description || body.error || '인증 시간이 만료되었습니다. 다시 시도해 주세요.');
    };
    setTimeout(poll, delay);
  } catch (error) { alert(error.message); }
}

async function finishLogin(data) {
  sessionStorage.setItem('sealinkSession', data.session);
  sessionStorage.setItem('sealinkUser', data.user.name);
  sessionStorage.setItem('sealinkUserId', data.user.id);
  const pending = sessionStorage.getItem('pendingRole') || selectedRole;
  const profile = await fetch('/api/profile', { method:'POST', headers:{'content-type':'application/json'}, body:JSON.stringify({role:pending}) });
  if (profile.ok) data.user = await profile.json();
  sessionStorage.setItem('sealinkRole', data.user.role || pending);
  sessionStorage.removeItem('pendingRole');
  view = 'home'; render();
}

function home() { renderHome(); refreshPosts(); refreshReplies(); }
function renderHome() {
  const viewer = sessionStorage.getItem('sealinkUser') || '';
  const card = p => {
    const mine = p.author_id === sessionStorage.getItem('sealinkUserId');
    const answers = receivedReplies.filter(r => r.post_id === p.id);
    return `<article class="post-card">${mine ? `<button class="post-delete" onclick="deletePost('${p.id}')">글 내리기</button>` : ''}<span class="post-badge">${p.role === 'ship' ? '선박' : '업체'} 연결글</span><b>${esc(p.title)}</b><p>${esc(p.body)}</p><small>${esc(p.author)} · ${esc(p.created_at)}</small>${mine ? `<div class="reply-list">${answers.length ? answers.map(r => `<div class="reply-item"><b>${esc(r.author)}</b><span>${esc(r.body)}</span><small>${esc(r.created_at)}</small><button class="reply-chat-button" onclick="openConversation('${p.id}','${r.owner_id}','${encodeURIComponent(p.title)}')">${esc(r.author)}와 계속 대화</button></div>`).join('') : '<span class="my-post-label">답변 대기 중</span>'}</div>` : (viewer ? `<button class="inapp-chat-button" onclick="openReply('${p.id}','${encodeURIComponent(p.title)}')">답변하기</button>` : '')}</article>`;
  };
  app.innerHTML = `<div class="content"><div class="welcome"><span class="ship-tag">${viewer ? `로그인 계정 · ${esc(viewer)}` : '로그인하면 답변할 수 있습니다'}</span><h2>공개 연결글</h2><p>연결글은 모두가 볼 수 있고, 답변과 대화는 당사자끼리만 확인할 수 있습니다.</p>${viewer ? '<button class="write-post-button" onclick="view=\'compose\';render()">+ 연결 글쓰기</button>' : ''}</div><div class="section-title">전체 연결글 <small class="post-count">${onlinePosts.length}건</small></div>${onlinePosts.length ? onlinePosts.map(card).join('') : '<div class="empty-post">아직 등록된 연결글이 없습니다.</div>'}${!viewer ? `<div class="section-title">회원별 로그인</div><div class="login-grid"><div class="login-card" onclick="openLogin('ship')"><b>⚓ 선박 페이지</b><span>선박 등록 및 폐선 상담</span><button>선박 로그인 →</button></div><div class="login-card company-login" onclick="openLogin('company')"><b>♻ 업체 페이지</b><span>업체 서비스 및 답변</span><button>업체 로그인 →</button></div></div>` : ''}</div>`;
}

async function refreshPosts() { try { const r = await fetch('/api/posts'); if (r.ok) { onlinePosts = await r.json(); renderHome(); } } catch {} }
async function refreshReplies() { if (!isLoggedIn()) return; try { const r = await fetch('/api/replies'); if (r.ok) { receivedReplies = await r.json(); renderHome(); } } catch {} }

function compose() { app.innerHTML = `<div class="content login-page"><div class="screen-head"><button class="back" onclick="view='home';render()">‹</button><div><h2>연결 글 작성</h2><small>등록한 글은 모든 회원에게 공개됩니다.</small></div></div><div class="login-form"><div class="role-pill">공개 연결글</div><label>게시글 제목</label><input id="postTitle" placeholder="어떤 연결이 필요하신가요?"><label>내용</label><textarea id="postBody" rows="6" placeholder="선박 상태, 필요한 서비스, 희망 일정 등을 작성해 주세요."></textarea><button class="btn btn-primary" onclick="publishPost()">연결 글 올리기 →</button></div></div>`; }
async function publishPost() { const title=document.querySelector('#postTitle').value.trim(), body=document.querySelector('#postBody').value.trim(); if (!title || !body) return alert('제목과 내용을 모두 입력해 주세요.'); const r=await fetch('/api/posts',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({title,body,role:sessionStorage.getItem('sealinkRole')||selectedRole})}); if(!r.ok) return alert('글을 올리지 못했습니다. 다시 시도해 주세요.'); view='home'; render(); }
async function deletePost(id) { if(!confirm('이 글을 서비스에서 내릴까요?')) return; const r=await fetch('/api/posts?id='+encodeURIComponent(id),{method:'DELETE'}); if(!r.ok) return alert('글을 내리지 못했습니다.'); await refreshPosts(); }

function openReply(id,title) { selected=[decodeURIComponent(title),'연결글 답변']; chatRoom=id; view='reply'; render(); }
function reply() { app.innerHTML = `<div class="content login-page"><div class="screen-head"><button class="back" onclick="view='home';render()">‹</button><div><h2>연결글 답변</h2><small>${esc(selected?.[0] || '')}</small></div></div><div class="login-form"><div class="role-pill">글 작성자에게만 전달됩니다</div><label>답변 내용</label><textarea id="replyBody" rows="6" placeholder="연결 가능 여부와 제안 내용을 작성해 주세요."></textarea><button class="btn btn-primary" onclick="sendReply()">답변 보내기 →</button></div></div>`; }
async function sendReply() { const body=document.querySelector('#replyBody').value.trim(); if(!body) return alert('답변 내용을 입력해 주세요.'); const r=await fetch('/api/replies',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({postId:chatRoom,body})}); if(!r.ok) return alert('답변을 보내지 못했습니다.'); view='home';render(); }

async function openConversation(postId, participantId, title) { const r=await fetch('/api/conversations',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({postId,participantId})}); const data=await r.json(); if(!r.ok) return alert(data.error||'대화방을 만들지 못했습니다.'); selected=[decodeURIComponent(title),'1:1 온라인 상담']; chatRoom='conversation-'+data.id; view='chat'; render(); }
function chat() { app.innerHTML=`<div class="content chat"><div class="screen-head"><button class="back" onclick="view='home';render()">‹</button><div><h2>${esc(selected?.[0]||'온라인 상담')}</h2><small><span class="online-dot">●</span> 1:1 온라인 대화</small></div></div><div class="messages" id="messages"><div class="empty">대화를 불러오는 중입니다.</div></div><div class="chat-input"><input id="msg" placeholder="메시지를 입력해 주세요" onkeydown="if(event.key==='Enter')send()"><button onclick="send()">↑</button></div></div>`; loadMessages(); chatPoll=setInterval(loadMessages,3000); }
async function loadMessages() { try { const r=await fetch('/api/messages?room='+encodeURIComponent(chatRoom)); if(!r.ok) return; const items=await r.json(), area=document.querySelector('#messages'); if(!area) return; const mine=sessionStorage.getItem('sealinkUserId'); area.innerHTML=items.length ? items.map(m=>`<div class="bubble ${m.owner_id===mine?'me':'them'}">${esc(m.body)}<span class="time">${esc(m.author)} · ${esc(m.created_at)}</span></div>`).join('') : '<div class="empty">첫 메시지를 보내 대화를 시작해 보세요.</div>'; area.scrollTop=area.scrollHeight; } catch {} }
async function send() { const input=document.querySelector('#msg'),body=input.value.trim(); if(!body)return; input.value=''; const r=await fetch('/api/messages',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({room:chatRoom,body})}); if(!r.ok) return alert('메시지를 보내지 못했습니다.'); loadMessages(); }

async function initAuth() { try { const r=await fetch('/api/me'); const data=await r.json(); if(!data.authenticated) return; sessionStorage.setItem('sealinkUser',data.user.name); sessionStorage.setItem('sealinkUserId',data.user.id); if(data.user.role) sessionStorage.setItem('sealinkRole',data.user.role); view='home'; render(); } catch {} }
render(); initAuth();
